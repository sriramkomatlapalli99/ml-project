Run the python main.py file in your terminal and the program will be executed.

For each goal three retrieved task trees are generated:- Iterative Deepening Search (IDDFS...), Greedy BFS using the h(n): success rate of motion as
the heuristic function (h1_greedy...)and Greedy BFS using h(n): number of input objects in the function unit (h2_greedy...)

N/B: No installed packages used